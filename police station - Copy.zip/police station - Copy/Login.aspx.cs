﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        txtuser.Text = "";
        txtpassword.Text = "";

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        encpass enc = new encpass();
        string str = "select * from registration where User_name='" + txtuser.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        if (ds.Tables[0].Rows.Count > 0)
        {
            str = "select * from registration where User_name='" + txtuser.Text + "'and Password='" + enc.EncryptConnectionString(txtpassword.Text )+ "'";
            DataSet dsp = new DataSet();
            dsp = dl.GetDataSet(str);
            if (dsp.Tables[0].Rows.Count > 0)
            {
                Session["uname"] = txtuser.Text;
                if (dsp.Tables[0].Rows[0]["User_type"].ToString() == "Admin")
                {
                    Response.Redirect("policedetails.aspx");
                }
                else if (dsp.Tables[0].Rows[0]["User_type"].ToString() == "Police")
                {
                    Response.Redirect("citizen.aspx");
                }
            }
            else
            {

                Response.Write("<script language='javascript'>alert('invalid User password...')</script>");
            }
        }
        else
        {
            Response.Write("<script language='javascript'>alert('User does not exist...')</script>");
        }


    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        
        
        Response.Redirect("Registration.aspx");
    }
}