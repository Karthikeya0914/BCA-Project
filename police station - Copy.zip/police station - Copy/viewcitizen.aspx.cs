﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class viewcitizen : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();

    public static string id = "";
   
    protected void Page_Load(object sender, EventArgs e)
    {
  
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

        string str = "select * from citizen_commitee where Area='" + ddlarea.SelectedItem.Text + "' and State='" + ddlstate.SelectedItem.Text + "' and City='" + ddlcity.SelectedItem.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
        GridView1.Visible = true;

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ddlarea.SelectedIndex = 0;
        ddlstate.SelectedIndex = 0;
        ddlcity.SelectedIndex = 0;
       
    }
}