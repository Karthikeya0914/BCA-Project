﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class viptourdetails : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public void filldropdown()
    {
        string str = "select * from station_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        ddlstation.DataSource = ds;
        ddlstation.DataTextField = "Name";
        ddlstation.DataValueField = "Station_id";
        ddlstation.DataBind();
        ddlstation.Items.Insert(0, new ListItem("Select station", "0"));

    }
    public static string id = "";
    public void fillgrid()
    {
        string str = "SELECT * FROM vip_tour_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
            filldropdown();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        encpass enc = new encpass();
        //String str1 = "select * from vip_tour_details where Name='" + ddlstation.Text + "'";
        //DataSet ds = new DataSet();
        //ds = dl.GetDataSet(str1);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
         //   Response.Write("<script language='javascript'>alert('user name already exist')</script>");

        //}
        //else
        //{

            String str = "insert into vip_tour_details(Vip_name,Proposed_date_of_departure,Arrival_unit,Place_of_arrival,Date_of_arrival,Visiting_places,Mode_of_journey,Type_of_security,Station_id)values('" + txtvipname.Text + "','" + txtpropose.Text + "','" + ddlunit.SelectedItem.Value + "','" + txtplace.Text + "','" + txtdate.Text + "','" + txtvisit.Text + "','" + txtmode.Text + "','" + txttype.Text + "','" + ddlstation.SelectedItem.Value +"')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Updated Successfully')</script>");
       // }
        fillgrid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ddlstation.SelectedIndex = 0;
        txtvipname.Text = "";
        txtpropose.Text = "";
        ddlunit.SelectedIndex = 0;
        txtplace.Text = "";
        txtdate.Text = "";
        txtvisit.Text = "";
        txtmode.Text = "";
        txttype.Text = "";
        
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str = "update vip_tour_details set Station_id='" + ddlstation.SelectedItem.Value + "',Vip_name='" + txtvipname.Text + "',Proposed_date_of_departure='" + txtpropose.Text + "',Arrival_unit='" + ddlunit.SelectedItem.Value + "',Place_of_arrival='" + txtplace.Text + "',Date_of_arrival='" + txtdate.Text + "',Visiting_places='" + txtvisit.Text + "',Mode_of_journey='" + txtmode.Text + "',Type_of_security='" + txttype.Text + "' where Vip_tour_details_id='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Updated Successfully')</script>");
        fillgrid();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        string str = "delete from vip_tour_details where Vip_tour_details_id ='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Deleted Successfully')</script>");
        fillgrid();
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView1.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
        txtvipname.Text = GridView1.Rows[rowIndex].Cells[1].Text;
        txtpropose.Text = GridView1.Rows[rowIndex].Cells[2].Text;
        ddlunit.Text = GridView1.Rows[rowIndex].Cells[3].Text;
        txtplace.Text = GridView1.Rows[rowIndex].Cells[4].Text;
        txtdate.Text = GridView1.Rows[rowIndex].Cells[5].Text;
        txtvisit.Text = GridView1.Rows[rowIndex].Cells[6].Text;
        txtmode.Text = GridView1.Rows[rowIndex].Cells[7].Text;
        txttype.Text = GridView1.Rows[rowIndex].Cells[8].Text;
        ddlstation.Text = GridView1.Rows[rowIndex].Cells[9].Text;
    }
    protected void txtvisit_TextChanged(object sender, EventArgs e)
    {

    }
}