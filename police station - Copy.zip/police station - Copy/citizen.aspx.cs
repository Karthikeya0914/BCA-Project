﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class citizen : System.Web.UI.Page
{
    
    DataLayer dl = new DataLayer();

    public static string id = "";
    public void fillgrid()
    {
        string str = "SELECT * FROM citizen_commitee c";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView2.DataSource = ds;
        GridView2.DataMember = "table";
        GridView2.DataBind();
    }
   
    protected void Page_Load(object sender, EventArgs e)
    {
         if (!IsPostBack)
        {
          
            fillddl1();
        
         }
    }
       public void fillddl1()
    {
        string str = "select * from station_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        ddlstation.DataSource = ds;
        ddlstation.DataTextField = "Name";
        ddlstation.DataValueField = "Station_id";
        ddlstation.DataBind();
        ddlstation.Items.Insert(0, new ListItem("Select Station", "0"));
        

    }
    protected void  Button1_Click(object sender, EventArgs e)
{
        // string str1 = "select * from citizen_commitee where Beat_no ='" + txtbeat.Text + "'";
        //DataSet ds = new DataSet();
        //ds = dl.GetDataSet(str1);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Response.Write("<script language='javascript'>alert(' name already exist')</script>");

        //}
        //else
        {
            if (txtphone.Text.Length < 10)
            {
                Response.Write("<script language='javascript'>alert('Enter Maximum 10 digits for Phone')</script>");
                return;
            }
            string str = "insert into citizen_commitee(Beat_no, Name, Father_name, Citizen_type, Area, Age, Religion, Caste, Address, State, District, Pincode, Phone,  Email,Station_id,City)values('" + txtbeat.Text + "','" + txtname.Text + "','" + txtfather.Text + "','" + ddlcitizen.SelectedItem.Value + "','" + ddlarea.SelectedItem.Value + "','" + txtage.Text + "','" + ddlreligion.SelectedItem.Value + "','" + ddlcaste.Text + "','" + txtaddress.Text + "','" + ddlstate.SelectedItem.Value + "','" + ddldistrict.SelectedItem.Value + "','" + txtpincode.Text + "','" + txtphone.Text + "','" + txtemail.Text + "','" + ddlstation.SelectedItem.Value+"','"+ddlcity.SelectedItem.Value + "')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Saved Sucessfully')</script>");
        }

        fillgrid();
        GridView2.Visible = true;
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        txtbeat.Text = "";
        txtname.Text = "";
        txtfather.Text = "";
        ddlcitizen.SelectedIndex = 0;
        ddlarea.SelectedIndex = 0;
        txtage.Text = "";
        ddlreligion.SelectedIndex = 0;
        ddlcaste.SelectedIndex = 0;
        txtaddress.Text = "";
        ddlstate.SelectedIndex = 0;
        ddldistrict.SelectedIndex = 0;
        txtpincode.Text = "";
        txtphone.Text = "";
        
        txtemail.Text = "";
       ddlcity.SelectedIndex= 0;

    }
    protected void ddldistrict_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtname_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtemail_TextChanged(object sender, EventArgs e)
    {

    }
}
