﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class policedetails : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public void filldropdown()
    {
        string str = "select * from station_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        ddlstation.DataSource = ds;
        ddlstation.DataTextField = "Name";
        ddlstation.DataValueField = "Station_id";
        ddlstation.DataBind();
        ddlstation.Items.Insert(0, new ListItem("Select station", "0"));

    }

    public static string id = "";
    public void fillgrid()
    {
        string str = "SELECT * FROM police_details ";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
            filldropdown();
        }

    }
    protected void btninsert_Click(object sender, EventArgs e)
    {

    //string str1 = "select * from  police_details where Station_id='" + ddlstation.Text + "'";
        //DataSet ds = new DataSet();
        //ds = dl.GetDataSet(str1);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Response.Write("<script language='javascript'>alert(' name already exist')</script>");

        //}
        //else
        DateTime dt = Convert.ToDateTime(txtdate.Text);
        if (dt > DateTime.Today)
        {
            Response.Write("<script language='javascript'>alert('Cannot Enter Tommorrows Date')</script>");
            return;
        }
        
                string str = "insert into  police_details(Station_id, Designation, Gender, Date_of_birth,Police_name)values('" + ddlstation.SelectedItem.Value + "','" + ddldesignation.SelectedItem.Value + "','" + ddlgender.SelectedItem.Value + "','" + txtdate.Text + "','" + txtpolice.Text + "')";
                dl.DmlCmd(str);
                fillgrid();
                Response.Write("<script language='javascript'>alert('Record Saved Successfully')</script>");
            

            //if (dt < DateTime.Today)
            //{
            //    Response.Write("<script language='javascript'>alert('You cannot enter Previous Days Date')</script>");
            //    return;
            //}
        }
       
           

    
 protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView1.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
        //ddlstation.Text = GridView1.Rows[rowIndex].Cells[1].Text;
        ddldesignation.Text = GridView1.Rows[rowIndex].Cells[1].Text;
        ddlgender.Text = GridView1.Rows[rowIndex].Cells[2].Text;
        txtdate.Text = GridView1.Rows[rowIndex].Cells[3].Text;
        txtpolice.Text = GridView1.Rows[rowIndex].Cells[4].Text;
        
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str = "update police_details set Station_id='" + ddlstation.SelectedItem.Value+ "',Designation='" + ddldesignation.Text + "',Gender='" + ddlgender.Text + "',Date_of_birth='" + txtdate.Text + "' where Police_id='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Updated Sucessfully')</script>");
        fillgrid();
    }
    protected void ddlstation_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        string str = "delete from  police_details where Police_id ='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Deleted Successfully')</script>");
        fillgrid();
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ddlstation.SelectedIndex = 0;
        ddldesignation.Text = "";
        ddlgender.Text = "";
        txtdate.Text = "";
        txtpolice.Text = "";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtdesignation_TextChanged(object sender, EventArgs e)
    {

    }
    
    }
