﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Changepasswod : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnclear1_Click(object sender, EventArgs e)
    {
        txtcurrent.Text = "";
        txtnew.Text = "";
        txtconfirm.Text = "";
       
    }
    //protected void btnchange_Click(object sender, EventArgs e)
    //{

    //    string str = "select * from registration where User_name='" + Session["uname"].ToString()+"'and Password='"+txtcurrent.Text+"'";
    //    DataSet ds = new DataSet();
    //    ds = d1.GetDataSet(str);
    //}
    protected void Button1_Click(object sender, EventArgs e)
    {

        string str = "select * from registration where User_name='" + Session["uname"].ToString() + "' and Password='" + txtcurrent.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        if (ds.Tables[0].Rows.Count > 0)
        {
            if (txtnew.Text.Length < 8)
            {
                Response.Write("<script language='javascript'>alert('Password must be minimum 8 characters')</script");
            }
            else if (txtnew.Text.Length > 8)
            {
                str = "update registration set Password='" + txtnew.Text + "' where User_name='" + Session["uname"].ToString() + "'";
                dl.DmlCmd(str);
                Response.Write("<script language='javascript'>alert('Password Successfully Changed ')</script");   
            }
            
        }
        else
        {
            Response.Write("<script language='javascript'>alert('Invalid old password')</script");
        }
           
    }
}
    
