﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class dutyboard : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();

    public static string id = "";

    public void fillddl1()
    {
        string str = "select * from police_details ";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        ddlpolice.DataSource = ds;
        ddlpolice.DataTextField = "Police_name";
        ddlpolice.DataValueField = "Police_id";
        ddlpolice.DataBind();
        ddlpolice.Items.Insert(0, new ListItem("Select police", "0"));


    }
    private void fillGrid()
    {
        string str = "select * from police_details where Police_name='" + ddlpolice.SelectedItem.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
    }
   
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
           
            fillddl1();
            //fillddl2();
          
        }
    }
    
    
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ddlpolice.SelectedIndex = 0;
        ddldistrict.SelectedIndex=0 ;
        ddlunittype.SelectedIndex= 0;
       
        txtfromdate.Text = "";
        txttodate.Text = "";

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        encpass enc = new encpass();

        String str = "insert into duty_board(Police_id, District, Unit_type,  From_date, To_date)values('" + ddlpolice.SelectedItem.Value + "','" + ddldistrict.SelectedItem.Value+ "','" + ddlunittype.SelectedItem.Value + "','"+ txtfromdate.Text + "','" + txttodate.Text + "')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Saved Sucessfully')</script>");
        
    }
   
    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    int rowIndex = Convert.ToInt32(e.CommandArgument);
    //    GridViewRow row = GridView1.Rows[rowIndex];
    //    Label lblid = (Label)row.FindControl("lblID");
    //    id = lblid.Text;
    //    ddlpolice.Text = GridView1.Rows[rowIndex].Cells[1].Text;
    //    ddldistrict.Text = GridView1.Rows[rowIndex].Cells[2].Text;
    //    ddlunit.Text = GridView1.Rows[rowIndex].Cells[3].Text;
    //    txtunits.Text = GridView1.Rows[rowIndex].Cells[4].Text;
    //    txtfromdate.Text = GridView1.Rows[rowIndex].Cells[5].Text;
    //    txttodate.Text = GridView1.Rows[rowIndex].Cells[6].Text;
    //}

    //protected void btnview_Click(object sender, EventArgs e)
    //{
    //    fillgrid();
    //    GridView1.Visible = true;
    //}

    protected void ddlpolice_SelectedIndexChanged1(object sender, EventArgs e)
    {
        fillGrid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillGrid();
    }
}