﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class petitionendrosement : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            
            fillgrid();

        }
    }

    public void fillgrid()
    {

        string str = "Select * from petition_register where Status='Pending'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        
        GridView1.DataBind();

    }
    //public void filldropdown()
    //{

    //    string str = "SELECT * FROM petition_register ";
    //    DataSet ds = new DataSet();
    //    ds = dl.GetDataSet(str);
    //    ddlpetition.DataSource = ds;
    //    ddlpetition.DataTextField = "Petition_type";
    //    ddlpetition.DataValueField = "Petition_register_id";
    //    ddlpetition.DataBind();
    //}
    //protected void Button2_Click(object sender, EventArgs e)
    //{

    //    ////String str1 = "select * from petition_endrosement where District ='" + ddldistrict.Text + "'";
    //    ////DataSet ds = new DataSet();
    //    ////ds = dl.GetDataSet(str1);
    //    ////if (ds.Tables[0].Rows.Count > 0)
    //    ////{
    //    ////    Response.Write("<script language='javascript'>alert('user name already exist')</script>");

    //    ////}
    //    ////else
    //    {

    //        String str = "insert into petition_endrosement( Petition_register_id,District, Unit_type, Units, Petition_type, Classification, Reference_no)values('" +txtpetition.Text + "','" + ddldistrict.SelectedItem.Value + "','" + ddlunit.SelectedItem.Value + "','" + txtunit.Text + "','" + txtclassification.Text + "','" + txtreference.Text + "')";
    //        dl.DmlCmd(str);
    //    }

    //}
    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    txtpetition.Text = "";
    //    ddldistrict.Text = "";
    //    ddlunit.Text = "";
    //    txtunit.Text = "";

    //    txtclassification.Text = "";
    //    txtreference.Text = "";

    //}
    //protected void Button1_Click1(object sender, EventArgs e)
    //{

    //    fillgrid();
    //    GridView1.Visible = true;
    //}


    //protected void btnsave1_Click(object sender, EventArgs e)
    //{
    //  String str ="insert into endrosement 
    //}
    protected void btnclear1_Click(object sender, EventArgs e)
    {
        txtreason.Text = "";
        ddlstatus.SelectedIndex = 0;

    }
    protected void btnsave1_Click(object sender, EventArgs e)
    {

        String str = " Update petition_register set Status='" + ddlstatus.SelectedItem.Text + "'where Petition_register_id='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Saved Successfully')</script>");
        fillgrid();

        dl.DmlCmd(str);
        

    
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView1.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
    }
    protected void txtreason_TextChanged(object sender, EventArgs e)
    {

    }
}