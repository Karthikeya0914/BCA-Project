﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net;
using System.Net.Mail;

public partial class forgot_password : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        string str = "";
        str = "select * from registration where User_name ='" + txtuname.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        if (ds.Tables[0].Rows.Count > 0)
        {
            String email = ds.Tables[0].Rows[0]["Email"].ToString();
            Random r = new Random();
            string s = r.NextDouble().ToString();
            s = s.Substring(3, 8);
            SmtpClient client = new SmtpClient("smtp.gmail.com");
            client.Port = 587;
            client.EnableSsl = true;
            client.Timeout = 100000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("varb393@gmail.com", "jogibettu");
            MailMessage msg = new MailMessage();
            msg.To.Add(email);
            msg.From = new MailAddress("varb393@gmail.com");

            msg.Subject = "forgot password";
            msg.Body = "your new passsword is='" + s + "'";
            client.Send(msg);
            str = "update registration set Password='" + s + "' where User_name='" + txtuname.Text + "'";
            dl.DmlCmd(str);
            
        }
        else
        {
            Response.Write("<script language='javaScript'>alert('Invalid user')</script>");
        }
    }
}