﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class viewdutyboard : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();

    public static string id = "";
    //public void fillgrid()
    //{
    //    string str = "select * from police_details where Police_name='" + ddlpolice.SelectedItem.Text + "'";
    //    DataSet ds = new DataSet();
    //    ds = dl.GetDataSet(str);
    //    GridView2.DataSource = ds;
    //    GridView2.DataMember = "table";
    //    GridView2.DataBind();
    //}
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string str = "select d.duty_board_id, p.Police_name, d.District, d.From_date, d.To_date from police_details p, duty_board d where p.Police_id=d.Police_id and d.Unit_type='" + ddlunit.SelectedItem.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView2.DataSource = ds;
        GridView2.DataMember = "table";
        GridView2.DataBind();
    }
}