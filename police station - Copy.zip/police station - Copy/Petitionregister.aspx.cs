﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Petitionregister : System.Web.UI.Page
{
     DataLayer dl = new DataLayer();
    public static string id = "";
    public void fillgrid()
    {
        string str = "SELECT * FROM petition_register p";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView2.DataSource = ds;
        GridView2.DataMember = "table";
        GridView2.DataBind();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //string str1 = "select * from  petition_register where Petition_type ='" + ddlpetition.SelectedItem.Text + "'";
        //DataSet ds = new DataSet();
        //ds = dl.GetDataSet(str1);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Response.Write("<script language='javascript'>alert(' name already exist')</script>");

        //}
        //else
        //DateTime dt = Convert.ToDateTime(txtdate.Text);
        //if (dt > DateTime.Today)
        //{
        //    Response.Write("<script language='javascript'>alert('Cannot Enter Tommorrows Date')</script>");
        //    return;
        //}


        string str = "insert into petition_register(Petition_type, Reference_number, Classification, Date_of_receipt, Facts_of_petition, Sent_to_district, Sent_to_unit, Petitioner_name, Address, Street, Father_name, Area, Status)values('" + ddlpetition.SelectedItem.Text + "','" + txtreference.Text + "','" + ddlclassification.SelectedItem.Text + "','" + txtdate.Text + "','" + txtfact.Text + "','" + ddldistrict.SelectedItem.Text + "','" + ddlunit.Text + "','" + txtpetitioner.Text + "','" + txtaddress.Text + "','" + txtstreet.Text + "','" + txtfather.Text + "','" + ddlarea.SelectedItem.Text + "','Pending')";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Saved Sucessfully')</script>");


        fillgrid();
        GridView2.Visible = true;
    }
    protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView2.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
        ddlpetition.Text = GridView2.Rows[rowIndex].Cells[1].Text;
        txtreference.Text = GridView2.Rows[rowIndex].Cells[2].Text;
        ddlclassification.Text = GridView2.Rows[rowIndex].Cells[3].Text;
        txtdate.Text = GridView2.Rows[rowIndex].Cells[4].Text;
        txtfact.Text = GridView2.Rows[rowIndex].Cells[5].Text;
        ddldistrict.Text = GridView2.Rows[rowIndex].Cells[6].Text;
        ddlunit.Text = GridView2.Rows[rowIndex].Cells[7].Text;
        txtpetitioner.Text = GridView2.Rows[rowIndex].Cells[8].Text;
        txtaddress.Text = GridView2.Rows[rowIndex].Cells[9].Text;
        txtstreet.Text = GridView2.Rows[rowIndex].Cells[10].Text;
        txtfather.Text = GridView2.Rows[rowIndex].Cells[11].Text;
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        string str = "delete from  petition_register where Petition_register_id='" + id + "'";
        dl.DmlCmd(str);
        fillgrid();
        Response.Write("<script language='javascript'>alert('Record Deleted Successfully')</script>");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str = "update petition_register  set Petition_type='" + ddlpetition.Text + "',Reference_number='" + txtreference.Text + "',Classification='" + ddlclassification.Text + "',Date_of_receipt='" + txtdate.Text + "',Facts_of_petition='" + txtfact.Text + "',Sent_to_district='" + ddldistrict.Text + "',Sent_to_unit='" + ddlunit.Text + "',Petitioner_name='" + txtpetitioner.Text + "',Address='" + txtaddress.Text + "',Street='" + txtstreet.Text + "',Father_name='" + txtfather.Text + "',Area='" + ddlarea.Text + "' where Petition_register_id='" + id + "'";
        dl.DmlCmd(str);
        fillgrid();
        Response.Write("<script language='javascript'>alert('Record Updated Sucessfully')</script>");
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {

        ddlpetition.SelectedIndex = 0;
        txtreference.Text = "";
        ddlclassification.SelectedIndex = 0;
        txtdate.Text = "";
        txtfact.Text = "";
        ddldistrict.SelectedIndex = 0;
        ddlunit.Text = "";
        txtpetitioner.Text = "";
        txtaddress.Text = "";
        txtstreet.Text = "";
        txtfather.Text = "";
        ddlarea.SelectedIndex = 0;
    }
}