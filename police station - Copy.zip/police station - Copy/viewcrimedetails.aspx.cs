﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class viewcrimedetails : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public string id = "";
    public void filldd1()
       {
        String str = "select * from crime_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        DropDownList2.DataSource = ds;
        DropDownList2.DataTextField = "Fir_no";
        DropDownList2.DataValueField = "Crime_details_id";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("Select fir no", "0"));

    }
    private void fillGrid()
    {
        String str = "select * from crime_details where Fir_no='" + DropDownList2.SelectedItem.Text + "'";
        DataSet ds = dl.GetDataSet(str);
        //ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
        
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //gridfill();
        if (!IsPostBack)
        {
            filldd1();   
        }
    }
    protected void  Button1_Click(object sender, EventArgs e)
    {
         String str = "update crime_details set status='Investigate' where Fir_no='" + DropDownList2.SelectedItem.Text+"'";
        dl.DmlCmd(str);
        fillGrid();
    }

protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
{
    
   fillGrid();
}
protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
{
    //int rowIndex = Convert.ToInt32(e.CommandArgument);
    //GridViewRow row = GridView1.Rows[rowIndex];
    //Label lblid = (Label)row.FindControl("lblID");
    //id = lblid.Text;
    //DropDownList2.Text = GridView1.Rows[rowIndex].Cells[1].Text;
    
}
protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
{
   
    fillGrid();
}

}

   
