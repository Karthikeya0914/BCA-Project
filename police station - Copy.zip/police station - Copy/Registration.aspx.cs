﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Accolade_SMS;

public partial class Registration : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
   // public void fillgrid()
   // {
   //     string str="select * from registration";
   // DataSet ds=new DataSet();
   // ds=dl.GetDataSet(str);
   // GridView1.DataSource=ds;
   //GridView1.DataMember="table";
   //GridView1.DataBind();
   // }
    
    protected void Page_Load(object sender, EventArgs e)
    {
       if(!IsPostBack)
        {
            //fillgrid();
        }
    }
    protected void btnclear2_Click(object sender, EventArgs e)
    {
        txtuser1.Text = "";
        txtpassword1.Text = "";
        txtconfirm1.Text = "";
        ddluser.SelectedIndex = 0;
        txtphone.Text = "";
        txtemail.Text = "";
       
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        encpass enc = new encpass();
        if (txtpassword1.Text.Length < 8)
        {
            Response.Write("<script language='javascript'>alert('Password Minimum 8 Character')</script>");
        }

        String str1 = "select * from registration where User_Name='" + txtuser1.Text + "'";
        DataSet ds=new DataSet();
        ds = dl.GetDataSet(str1);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>alert('user name already exist')</script>");

        }
        else
        {

            String str = "insert into registration(User_Name, Password, User_Type, Phone, Email)values('" + txtuser1.Text + "','" +enc.EncryptConnectionString(txtpassword1.Text) + "','" + ddluser.SelectedItem.Text + "','" + txtphone.Text + "','" + txtemail.Text + "')";
            dl.DmlCmd(str);
            ATS_SMS sms = new ATS_SMS();
            //sms.sendsms(txtphone.Text,"hyyyyy");
            Response.Write("<script language='javascript'>alert('succesfully registered')</script>");
            
               
        }
        //fillgrid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    //protected void btninsert_Click(object sender, EventArgs e)
    //{
    //    string str1 = "select * from registration where User_name='" + txtuser1.Text + "'";
    //    DataSet ds = new DataSet();
    //    ds = dl.GetDataSet(str1);
    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        Response.Write("<script language='javascript'>alert(' name already exist')</script>");

    //    }
    //    else
    //    {
    //        string str = "insert into registration(User_name, Password, User_type, Email, Phone)values('" + txtuser1.Text + "','" + txtpassword1.Text + "','" + ddluser.Text + "','" + txtemail.Text + "','" + txtphone.Text + "')";
    //        dl.DmlCmd(str);
    //    }
    //    fillgrid();
       

    //}
    protected void btndelete_Click(object sender, EventArgs e)
    {

        string str = "delete from  registration  where Reg_id ='" + id + "'";
        dl.DmlCmd(str);
        //fillgrid();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    int rowIndex = Convert.ToInt32(e.CommandArgument);
    //    GridViewRow row = GridView1.Rows[rowIndex];
    //    Label lblid = (Label)row.FindControl("lblID");
    //    id = lblid.Text;
    //    txtuser1.Text = GridView1.Rows[rowIndex].Cells[1].Text;
    //    txtpassword1.Text = GridView1.Rows[rowIndex].Cells[2].Text;
    //    ddluser.Text = GridView1.Rows[rowIndex].Cells[3].Text;
    //    txtemail.Text = GridView1.Rows[rowIndex].Cells[4].Text;
    //    txtphone.Text = GridView1.Rows[rowIndex].Cells[5].Text;
    //}
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str = "update registration set username='" + txtuser1.Text + "',password='" + txtpassword1.Text + "',usertype='" + ddluser.Text + "',email='" + txtemail.Text + "',phone='" + txtphone + "' where Reg_id ='" + id + "'";
        dl.DmlCmd(str);
        //fillgrid();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        
    }
}