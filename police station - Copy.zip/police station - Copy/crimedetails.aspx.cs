﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class crimedetails : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        fillddl1();
    }
    public void fillddl1()
    {
        string str = "select * from station_details";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        ddlstation.DataSource = ds;
        ddlstation.DataTextField = "Name";
        ddlstation.DataValueField = "Station_id";
        ddlstation.DataBind();
        ddlstation.Items.Insert(0, new ListItem("Select Station", "0"));

    }
    protected void ddlsubdivision_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        //String str1 = "select * from crime_details  where Fir_no='" + txtfir.Text + "'";
        //DataSet ds = new DataSet();
        //ds = dl.GetDataSet(str1);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Response.Write("<script language='javascript'>alert('user name already exist')</script>");

        //}
        //else
        DateTime dt = Convert.ToDateTime(txtfirdate.Text);
        if (dt > DateTime.Today)
        {
            Response.Write("<script language='javascript'>alert('Cannot Enter Tommorrows Date')</script>");
            return;
        }
        //else
        //{
        //    if (dt < DateTime.Today)
        //    {
        //        Response.Write("<script language='javascript'>alert('You cannot enter Previous Days Date')</script>");
        //        return;
        //    }
        //}

            String str = "insert into crime_details(Fir_no, District, Subdivision, Police_station_id, Fir_date, Act, Section, Place_of_occurance, Witness,Crime_Name,status)values('" + txtfir.Text + "','" + ddldistrict.SelectedItem.Text + "','" + ddlsubdivision.SelectedItem.Text + "','" + ddlstation.SelectedItem.Text + "','" + txtfirdate.Text + "','" + txtact.Text + "','" + txtsection.Text + "','" + ddlplace.SelectedItem.Text + "','" + txtwittness.Text + "','" + txtcrime.Text + "','pending')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Saved Sucessfully')</script>");
       
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        ddlstation.SelectedIndex = 0;
        txtfir.Text = "";
        ddldistrict.SelectedIndex = 0;
        ddlsubdivision.SelectedIndex = 0;
        txtfir.Text = "";
        txtact.Text = "";
        txtsection.Text = "";
        ddlplace.SelectedIndex = 0;
        txtwittness.Text = "";
        txtcrime.Text = "";


    }
}