﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class publicservice : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
    public void fillgrid()
    {
        string str = "SELECT * FROM public_service";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        encpass enc = new encpass();
        String str1 = "select * from public_service where Name='" + txtname.Text + "'";
        DataSet ds = new DataSet();
        ds = dl.GetDataSet(str1);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Response.Write("<script language='javascript'>alert('user name already exist')</script>");

        }
        else
        {
            if (txtcontact.Text.Length < 10)
            {
                Response.Write("<script language='javascript'>alert('Enter Maximum 10 digits')</script>");
                return;
            }
            String str = "insert into public_service(Name, Contact_no)values('" + txtname.Text + "','" + txtcontact.Text + "')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Saved Successfully')</script>");
        }
        fillgrid();
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        txtname.Text = "";
        txtcontact.Text = "";
        
    }
   
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView1.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
        txtname.Text = GridView1.Rows[rowIndex].Cells[1].Text;
        txtcontact.Text = GridView1.Rows[rowIndex].Cells[2].Text;
        
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        string str = "update public_service set Name='" + txtname.Text + "',Contact_no='" + txtcontact.Text + "' where Public_service_id='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Updated Successfully')</script>");
        fillgrid();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        string str = "delete from public_service where Public_service_id='" + id + "'";
        dl.DmlCmd(str);
        Response.Write("<script language='javascript'>alert('Record Deleted Successfully')</script>");
        fillgrid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void txtname_TextChanged(object sender, EventArgs e)
    {

    }
}