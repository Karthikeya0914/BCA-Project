﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class crimedetailsvictim : System.Web.UI.Page
{
    DataLayer dl = new DataLayer();
    public static string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        fillddl1();
    }
    public void fillddl1()
    {
        

    }
    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    int rowIndex = Convert.ToInt32(e.CommandArgument);
    //    GridViewRow row = GridView1.Rows[rowIndex];
    //    ddlcrime.Text = GridView1.Rows[rowIndex].Cells[1].Text;
    //    txtname.Text = GridView1.Rows[rowIndex].Cells[2].Text;
    //    ddlsex.Text = GridView1.Rows[rowIndex].Cells[3].Text;
    //    txtage.Text = GridView1.Rows[rowIndex].Cells[4].Text;
    //    txtoccupation.Text = GridView1.Rows[rowIndex].Cells[5].Text;
    //    txttype.Text = GridView1.Rows[rowIndex].Cells[6].Text;
    //}
    //protected void btnsearch_Click(object sender, EventArgs e)
    //{
    //    string str = "SELECT * FROM crime_details where Crime_Name='" + ddlcrime.SelectedItem.Text + "'";
    //    DataSet ds = new DataSet();
    //    ds = dl.GetDataSet(str);
    //    GridView2.DataSource = ds;
    //    GridView2.DataMember = "table";
    //    GridView2.DataBind();
    //    GridView2.Visible = true;

    //}Victim_details_id, is_police, type, type_of_injury, nationality, mean, state, city, area, gender
    protected void btnsave_Click(object sender, EventArgs e)
    {
        
            String gender = " ";
            string is_police = " ";
            if (rdmale.Checked == true)
            {
         
                gender = "male";
            }
            else
            {
                gender = "female";
            }
            if (Checkpolice.Checked == true)
            {
                is_police = "yes";
            }
            else
            {
                is_police = "no";
            }

            string str = "insert into victim_details(is_police, type, type_of_injury, nationality, mean, state, city, area, gender)values('" + is_police + "','" + ddltype.SelectedItem.Value + "','" + ddlinjury.SelectedItem.Value + "','" + ddlnationality.SelectedItem.Value + "','" + ddlmean.SelectedItem.Value + "','" + ddlstate.SelectedItem.Value + "','" + ddlcity.SelectedItem.Value + "','" + ddlarea.SelectedItem.Value + "','"+ gender+"')";
            dl.DmlCmd(str);
            Response.Write("<script language='javascript'>alert('Record Saved Sucessfully')</script>");
        
    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        Checkpolice.Checked = true ;
        ddltype.SelectedIndex = 0;
        ddlinjury.SelectedIndex = 0;
        ddlnationality.SelectedIndex = 0;
        ddlmean.SelectedIndex = 0;
        ddlstate.SelectedIndex = 0;
        ddlcity.SelectedIndex = 0;
        ddlarea.SelectedIndex = 0;
       


    }
    protected void rdfemale_CheckedChanged(object sender, EventArgs e)
    {

    }
}